import "./App.css";
import Agenda from "./components/agenda";

function App() {
  return (
    <>
      <Agenda></Agenda>
    </>
  )
}

export default App;
